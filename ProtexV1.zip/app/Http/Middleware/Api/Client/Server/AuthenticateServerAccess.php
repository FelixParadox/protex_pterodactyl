<?php

namespace Pterodactyl\Http\Middleware\Api\Client\Server;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\Server;

class AuthenticateServerAccess
{
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();
        if (! $user) {
            return $this->deny($request, 'Tidak terautentikasi.');
        }

        $server = $request->route('server') ?? null;
        if ($server && ! is_object($server)) {
            $server = Server::find($server);
            if (! $server) {
                return $this->deny($request, 'Server tidak ditemukan.');
            }
            $request->route()->setParameter('server', $server);
        }

        // If normal user (not admin) and not owner -> deny now
        if (! $user->root_admin) {
            if (! $server || intval($server->owner_id) !== intval($user->id)) {
                return $this->deny($request, 'Anda tidak memiliki akses ke server ini.');
            }
            return $next($request);
        }

        // Admin: do not prematurely deny. Let ProtexMiddleware decide for admin actions.
        return $next($request);
    }

    private function deny(Request $request, $message)
    {
        if ($request->expectsJson() || str_starts_with($request->path(), 'api/')) {
            return response()->json(['error' => $message], 403);
        }
        return response()->view('errors.403', ['message' => $message], 403);
    }
}