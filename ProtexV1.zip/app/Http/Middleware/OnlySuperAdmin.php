<?php

namespace Pterodactyl\Http\Middleware;

use Closure;

class OnlySuperAdmin
{
    public function handle($request, Closure $next)
    {
        $user = auth()->user();

        if (!$user || intval($user->id) !== 1) {
            abort(403, 'Anda tidak diizinkan mengakses halaman Protex.');
        }

        return $next($request);
    }
}