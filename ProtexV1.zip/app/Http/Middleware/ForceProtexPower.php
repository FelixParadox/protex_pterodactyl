<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\Server;

class ForceProtexPower
{
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();
        $server = $request->route('server');

        if ($server && !is_object($server)) {
            $server = Server::find($server);
        }

        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        // ROOT ADMIN ID1 → bebas
        if ($user->id == 1) {
            return $next($request);
        }

        // OWNER server → tetap boleh
        if ($server && $server->owner_id == $user->id) {
            return $next($request);
        }

        // ADMIN LAIN harus lewat protex_power
        $perms = $user->protex_permissions ?? [];
        if (!is_array($perms)) {
            $perms = (array)$perms;
        }

        if (empty($perms['power']) || $perms['power'] !== true) {
            return response()->json(['error' => 'Akses POWER ditolak oleh PROTEX'], 403);
        }

        return $next($request);
    }
}