<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\Response;
use Pterodactyl\Models\Mount;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\Database;
use Pterodactyl\Models\MountServer;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Services\Servers\SuspensionService;
use Pterodactyl\Repositories\Eloquent\MountRepository;
use Pterodactyl\Services\Servers\ServerDeletionService;
use Pterodactyl\Services\Servers\ReinstallServerService;
use Pterodactyl\Exceptions\Model\DataValidationException;
use Pterodactyl\Repositories\Wings\DaemonServerRepository;
use Pterodactyl\Services\Servers\BuildModificationService;
use Pterodactyl\Services\Databases\DatabasePasswordService;
use Pterodactyl\Services\Servers\DetailsModificationService;
use Pterodactyl\Services\Servers\StartupModificationService;
use Pterodactyl\Contracts\Repository\NestRepositoryInterface;
use Pterodactyl\Repositories\Eloquent\DatabaseHostRepository;
use Pterodactyl\Services\Databases\DatabaseManagementService;
use Illuminate\Contracts\Config\Repository as ConfigRepository;
use Pterodactyl\Contracts\Repository\ServerRepositoryInterface;
use Pterodactyl\Contracts\Repository\DatabaseRepositoryInterface;
use Pterodactyl\Contracts\Repository\AllocationRepositoryInterface;
use Pterodactyl\Services\Servers\ServerConfigurationStructureService;
use Pterodactyl\Http\Requests\Admin\Servers\Databases\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /*--------------------------------------------------------------
      🛡️ Proteksi: Jangan izinkan modifikasi server milik Admin Utama (ID=1)
    --------------------------------------------------------------*/
    private function blockIfServerOwnerIsSuperAdmin(Server $server)
    {
        $auth = auth()->user();

        // Admin Utama (ID=1) bebas edit semua server
        if ($auth->id === 1) {
            return;
        }

        // Jika server dimiliki Admin Utama, admin lain TIDAK BOLEH ubah apa pun
        if ($server->owner_id === 1) {
            throw new DisplayException("Anda tidak diizinkan mengubah server milik Admin Utama.");
        }
    }

    /*--------------------------------------------------------------
       UPDATE SERVER DETAILS
    --------------------------------------------------------------*/
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /*--------------------------------------------------------------
       TOGGLE INSTALL
    --------------------------------------------------------------*/
    public function toggleInstall(Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /*--------------------------------------------------------------
       REINSTALL SERVER
    --------------------------------------------------------------*/
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /*--------------------------------------------------------------
       SUSPEND / UNSUSPEND
    --------------------------------------------------------------*/
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success("Server berhasil {$request->input('action')}ed")->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /*--------------------------------------------------------------
       UPDATE BUILD
    --------------------------------------------------------------*/
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /*--------------------------------------------------------------
       DELETE SERVER
    --------------------------------------------------------------*/
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /*--------------------------------------------------------------
       STARTUP MODIFY
    --------------------------------------------------------------*/
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $data = $request->except('_token');

        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /*--------------------------------------------------------------
       DATABASE CRUD
    --------------------------------------------------------------*/
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $database = $server->databases()->findOrFail($request->input('database'));
        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $this->databaseManagementService->delete($database);
        return response('', 204);
    }

    /*--------------------------------------------------------------
       MOUNTS
    --------------------------------------------------------------*/
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount added successfully.')->flash();
        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        $this->blockIfServerOwnerIsSuperAdmin($server);

        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount removed successfully.')->flash();
        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}