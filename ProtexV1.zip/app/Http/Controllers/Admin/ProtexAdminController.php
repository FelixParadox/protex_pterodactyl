<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\User;
use Illuminate\Http\Request;

class ProtexAdminController extends Controller
{
    public function index()
    {
        $admins = User::where('root_admin', 1)->get();
        return view('admin.protex.index', compact('admins'));
    }

    public function edit(User $user)
    {
        $permissions = $user->protex_permissions ?? [];
        return view('admin.protex.edit', compact('user', 'permissions'));
    }

    public function save(Request $request, User $user)
    {
        // expected input: permissions[permission_key] = 1
        $input = $request->input('permissions', []);
        $clean = [];
        foreach ($input as $key => $val) {
            $clean[$key] = true;
        }

        $user->protex_permissions = $clean;
        $user->save();

        return redirect()->route('admin.protex.index')->with('status', 'Permissions updated.');
    }
}